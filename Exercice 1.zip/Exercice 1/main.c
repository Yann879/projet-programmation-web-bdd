#include <stdio.h>

int main() {
    int nbMatieres;
    float notes[100]; // tableau pour stocker les notes
    float somme = 0, moyenne;

    // Demande du nombre de mati�res
    printf("Combien de mati�res avez-vous ? ");
    scanf("%d", &nbMatieres);

    // V�rification
    if (nbMatieres <= 0 || nbMatieres > 100) {
        printf("Nombre de mati�res invalide.\n");
        return 1;
    }

    // Saisie des notes
    for (int i = 0; i < nbMatieres; i++) {
        do {
            printf("Entrez la note pour la mati�re %d (entre 0 et 20) : ", i + 1);
            scanf("%f", &notes[i]);

            if (notes[i] < 0 || notes[i] > 20) {
                printf("Note invalide. Essayez encore.\n");
            }

        } while (notes[i] < 0 || notes[i] > 20);

        somme += notes[i];
    }

    // Calcul de la moyenne
    moyenne = somme / nbMatieres;

    // Affichage des notes
    printf("\n--- Notes des mati�res ---\n");
    for (int i = 0; i < nbMatieres; i++) {
        printf("Mati�re %d : %.2f\n", i + 1, notes[i]);
    }

    // Affichage de la moyenne
    printf("\nLa moyenne de l'�tudiant est : %.2f\n", moyenne);

    // Attribution de la mention
    if (moyenne > 16) {
        printf("Mention : Excellent\n");
    } else if (moyenne > 12 && moyenne <= 16) {
        printf("Mention : Bien\n");
    } else if (moyenne > 10 && moyenne <= 12) {
        printf("Mention : Passable\n");
    } else {
        printf("Mention : Insuffisant\n");
    }

    return 0;
}
